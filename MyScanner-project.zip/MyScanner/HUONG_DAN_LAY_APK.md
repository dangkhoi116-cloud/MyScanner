# Hướng dẫn lấy file APK (không cần cài Android Studio)

Mục tiêu: có file `app-debug.apk` nằm trên **máy tính** của anh, sau đó anh gửi qua **Zalo / Google Drive** về điện thoại để cài.

Vì việc biên dịch cần máy chủ của Google, ta sẽ để **GitHub build miễn phí trên mạng**, rồi tải APK về. Toàn bộ làm trên trình duyệt, không cần cài phần mềm.

---

## Bước 1 — Tạo tài khoản GitHub (miễn phí)

1. Vào https://github.com → bấm **Sign up**.
2. Nhập email, mật khẩu, tên đăng nhập → xác nhận email.

(Nếu anh đã có tài khoản thì bỏ qua bước này.)

## Bước 2 — Tạo kho chứa dự án (repository)

1. Đăng nhập GitHub → góc trên bên phải bấm dấu **+** → **New repository**.
2. Đặt tên ví dụ `MyScanner`, để chế độ **Public** (hoặc Private đều được).
3. Bấm **Create repository**.

## Bước 3 — Tải dự án lên (upload)

1. Giải nén file `MyScanner-project.zip` em đã gửi → được thư mục `MyScanner`.
2. Trong trang repo vừa tạo, bấm **uploading an existing file** (hoặc nút **Add file ▸ Upload files**).
3. Kéo **toàn bộ nội dung bên trong thư mục MyScanner** (các thư mục `app`, `gradle`, file `build.gradle`, `settings.gradle`, thư mục `.github` ...) thả vào trang.
   - Lưu ý: kéo *nội dung bên trong* MyScanner, không kéo cả thư mục MyScanner, để các file nằm ở gốc repo.
4. Bấm **Commit changes**.

## Bước 4 — Đợi GitHub tự build

1. Trong repo bấm tab **Actions** ở trên cùng.
2. Sẽ thấy một tiến trình tên **Build APK** đang chạy (vòng tròn vàng). Đợi khoảng **3–6 phút** cho tới khi thành công (dấu tích xanh ✅).
   - Nếu chưa tự chạy: bấm vào **Build APK** ở cột trái → bấm **Run workflow**.

## Bước 5 — Tải file APK về máy tính

1. Bấm vào lần build vừa thành công (dòng có dấu tích xanh).
2. Kéo xuống mục **Artifacts** ở cuối trang → bấm **MyScanner-apk** để tải về.
3. File tải về là `.zip`, giải nén ra sẽ có **`app-debug.apk`**.

## Bước 6 — Gửi sang điện thoại và cài

1. Gửi file `app-debug.apk` qua **Zalo** (gửi cho chính mình) hoặc tải lên **Google Drive**.
2. Trên điện thoại, mở file `app-debug.apk` → bấm **Cài đặt**.
3. Lần đầu Android sẽ hỏi cho phép "Cài ứng dụng từ nguồn không xác định" → bật cho phép → cài tiếp.
4. Mở app **MyScanner** và dùng.

> Điện thoại cần có **Google Play Services** (gần như máy Android nào cũng có sẵn). Lần quét đầu tiên app sẽ tự tải thêm module quét của Google.

---

## Cách khác: dùng Android Studio (nếu anh thích build trên máy)

1. Tải **Android Studio** miễn phí tại https://developer.android.com/studio và cài.
2. Mở Android Studio → **File ▸ Open** → chọn thư mục `MyScanner`.
3. Đợi tải Gradle + thư viện (lần đầu vài phút, cần mạng).
4. Menu **Build ▸ Build Bundle(s) / APK(s) ▸ Build APK(s)**.
5. Build xong bấm **locate** → ra file `app/build/outputs/apk/debug/app-debug.apk`.
6. Copy file đó gửi sang điện thoại như Bước 6 ở trên.
