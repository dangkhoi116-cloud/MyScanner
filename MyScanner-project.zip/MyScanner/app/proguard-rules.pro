# Giu lai cac lop ML Kit
-keep class com.google.mlkit.** { *; }
-keep class com.google.android.gms.** { *; }
