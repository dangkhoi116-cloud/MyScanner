package com.linh.myscanner

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.linh.myscanner.databinding.ActivityDetailBinding
import java.io.File

class DocumentDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding
    private var doc: ScannedDoc? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val docId = intent.getStringExtra("docId")
        doc = DocumentStore.load(this).firstOrNull { it.id == docId }
        val d = doc ?: run { finish(); return }

        binding.toolbar.title = d.name
        binding.toolbar.setNavigationOnClickListener { finish() }

        binding.pagesRecycler.layoutManager = LinearLayoutManager(this)
        binding.pagesRecycler.adapter = PageAdapter(d.pages)

        binding.btnExport.setOnClickListener { exportPdf(d) }
        binding.btnShare.setOnClickListener { sharePdf(d) }
        binding.btnOcr.setOnClickListener { runOcr(d) }
    }

    /** Tra ve file PDF: dung ban ML Kit tao san, neu khong co thi tu dung tu anh. */
    private fun ensurePdf(d: ScannedDoc): File {
        d.pdfPath?.let { p ->
            val f = File(p)
            if (f.exists()) return f
        }
        val out = File(DocumentStore.newDocDir(this, d.id), "${d.id}.pdf")
        PdfHelper.buildPdf(d.pages, out)
        d.pdfPath = out.absolutePath
        DocumentStore.update(this, d)
        return out
    }

    private fun exportPdf(d: ScannedDoc) {
        val pdf = ensurePdf(d)
        Toast.makeText(this, "Đã tạo PDF: ${pdf.name}", Toast.LENGTH_SHORT).show()
        sharePdf(d)
    }

    private fun sharePdf(d: ScannedDoc) {
        val pdf = ensurePdf(d)
        val uri: Uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", pdf)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, getString(R.string.share)))
    }

    private fun runOcr(d: ScannedDoc) {
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val progress = AlertDialog.Builder(this)
            .setMessage("Đang nhận dạng văn bản...")
            .setCancelable(false)
            .create()
        progress.show()

        val sb = StringBuilder()
        fun processPage(i: Int) {
            if (i >= d.pages.size) {
                progress.dismiss()
                showOcrResult(d, sb.toString().trim())
                return
            }
            val image = InputImage.fromFilePath(this, Uri.fromFile(File(d.pages[i])))
            recognizer.process(image)
                .addOnSuccessListener { text ->
                    if (d.pages.size > 1) sb.append("--- Trang ${i + 1} ---\n")
                    sb.append(text.text).append("\n\n")
                    processPage(i + 1)
                }
                .addOnFailureListener {
                    sb.append("[Lỗi đọc trang ${i + 1}]\n\n")
                    processPage(i + 1)
                }
        }
        processPage(0)
    }

    private fun showOcrResult(d: ScannedDoc, text: String) {
        val tv = TextView(this).apply {
            setText(if (text.isBlank()) "Không nhận dạng được văn bản." else text)
            setTextIsSelectable(true)
            setPadding(48, 32, 48, 32)
        }
        val scroll = ScrollView(this).apply { addView(tv) }

        AlertDialog.Builder(this)
            .setTitle(R.string.ocr_result)
            .setView(scroll)
            .setPositiveButton(R.string.copy) { _, _ ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText(d.name, text))
                Toast.makeText(this, "Đã sao chép", Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton(R.string.share) { _, _ -> shareText(d, text) }
            .setNegativeButton("Đóng", null)
            .show()
    }

    private fun shareText(d: ScannedDoc, text: String) {
        val txtFile = File(cacheDir, "${d.name}.txt").apply { writeText(text) }
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", txtFile)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, getString(R.string.share)))
    }
}
