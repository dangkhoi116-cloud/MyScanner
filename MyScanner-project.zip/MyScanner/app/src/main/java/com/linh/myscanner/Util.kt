package com.linh.myscanner

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Util {
    fun outDir(ctx: Context): File =
        File(ctx.getExternalFilesDir(null), "KBCScanner").apply { if (!exists()) mkdirs() }

    fun stamp(): String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    fun copyUriToCache(ctx: Context, uri: Uri, name: String): File {
        val f = File(ctx.cacheDir, name)
        ctx.contentResolver.openInputStream(uri)?.use { input ->
            f.outputStream().use { out -> input.copyTo(out) }
        }
        return f
    }

    fun queryName(ctx: Context, uri: Uri): String {
        var name = "file"
        try {
            ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && c.moveToFirst()) name = c.getString(i)
            }
        } catch (_: Exception) {}
        return name
    }

    fun uriFor(ctx: Context, f: File): Uri =
        FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)

    fun mimeOf(f: File): String = when (f.extension.lowercase()) {
        "pdf" -> "application/pdf"
        "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        else -> "*/*"
    }

    fun open(ctx: Context, f: File) {
        val uri = uriFor(ctx, f)
        val i = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mimeOf(f))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ctx.startActivity(Intent.createChooser(i, "Mở bằng"))
    }

    fun share(ctx: Context, f: File) {
        val uri = uriFor(ctx, f)
        val i = Intent(Intent.ACTION_SEND).apply {
            type = mimeOf(f)
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(i, "Chia sẻ"))
    }
}
