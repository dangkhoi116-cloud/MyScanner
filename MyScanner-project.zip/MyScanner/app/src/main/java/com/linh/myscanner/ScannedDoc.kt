package com.linh.myscanner

import org.json.JSONArray
import org.json.JSONObject

/** Mot tai lieu da quet, gom nhieu trang anh + (tuy chon) file PDF. */
data class ScannedDoc(
    val id: String,
    var name: String,
    val createdAt: Long,
    val pages: MutableList<String> = mutableListOf(), // duong dan file anh
    var pdfPath: String? = null
) {
    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("id", id)
        o.put("name", name)
        o.put("createdAt", createdAt)
        o.put("pdfPath", pdfPath ?: JSONObject.NULL)
        val arr = JSONArray()
        pages.forEach { arr.put(it) }
        o.put("pages", arr)
        return o
    }

    companion object {
        fun fromJson(o: JSONObject): ScannedDoc {
            val pages = mutableListOf<String>()
            val arr = o.optJSONArray("pages") ?: JSONArray()
            for (i in 0 until arr.length()) pages.add(arr.getString(i))
            return ScannedDoc(
                id = o.getString("id"),
                name = o.getString("name"),
                createdAt = o.getLong("createdAt"),
                pages = pages,
                pdfPath = if (o.isNull("pdfPath")) null else o.optString("pdfPath", null)
            )
        }
    }
}
