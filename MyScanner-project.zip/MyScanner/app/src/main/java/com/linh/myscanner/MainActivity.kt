package com.linh.myscanner

import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import com.linh.myscanner.databinding.ActivityMainBinding
import com.linh.myscanner.databinding.ViewTileBinding
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    // ---- Launchers ----
    private val captureLauncher = registerForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val r = GmsDocumentScanningResult.fromActivityResultIntent(result.data)
            val pdf = r?.pdf
            if (pdf != null) {
                process("Đang lưu PDF...") {
                    val out = File(Util.outDir(this), "Scan_${Util.stamp()}.pdf")
                    contentResolver.openInputStream(pdf.uri)?.use { i ->
                        out.outputStream().use { o -> i.copyTo(o) }
                    }
                    listOf(out)
                }
            }
        }
    }

    private val pickImagesForPdf = registerForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris ->
        if (uris.isNotEmpty()) process("Đang tạo PDF...") { listOf(Converters.imagesToPdf(this, uris)) }
    }

    private val pickDocx = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { process("Đang chuyển Word → PDF...") { listOf(Converters.wordToPdf(this, toTemp(it, "docx"))) } }
    }

    private val pickPdfWord = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { process("Đang chuyển PDF → Word...") { listOf(Converters.pdfToWord(this, toTemp(it, "pdf"))) } }
    }

    private val pickPdfImg = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { process("Đang chuyển PDF → Ảnh...") { Converters.pdfToImages(this, toTemp(it, "pdf")) } }
    }

    private val pickPdfsMerge = registerForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris ->
        if (uris.size < 2) { toast("Hãy chọn ít nhất 2 file PDF"); return@registerForActivityResult }
        process("Đang ghép PDF...") {
            val files = uris.mapIndexed { i, u -> toTemp(u, "pdf", "merge$i") }
            listOf(Converters.mergePdfs(this, files))
        }
    }

    private val pickPdfSplit = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { process("Đang tách PDF...") { Converters.splitPdf(this, toTemp(it, "pdf")) } }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        tile(binding.tileCapture, R.drawable.ic_camera, R.drawable.box_green, "Chụp ảnh\n→ PDF") { startCapture() }
        tile(binding.tileImages, R.drawable.ic_gallery, R.drawable.box_blue, "Ảnh có sẵn\n→ PDF") { pickImagesForPdf.launch("image/*") }

        tile(binding.tileWordPdf, R.drawable.ic_word, R.drawable.box_blue, "Word\n→ PDF") { pickDocx.launch("*/*") }
        tile(binding.tilePdfWord, R.drawable.ic_pdf, R.drawable.box_green, "PDF\n→ Word") { pickPdfWord.launch("application/pdf") }
        tile(binding.tilePdfImg, R.drawable.ic_image, R.drawable.box_purple, "PDF\n→ Ảnh") { pickPdfImg.launch("application/pdf") }

        tile(binding.tileMerge, R.drawable.ic_merge, R.drawable.box_orange, "Ghép\nPDF") { pickPdfsMerge.launch("application/pdf") }
        tile(binding.tileSplit, R.drawable.ic_split, R.drawable.box_red, "Tách\nPDF") { pickPdfSplit.launch("application/pdf") }

        binding.recentRecycler.layoutManager = LinearLayoutManager(this)
        binding.btnClear.setOnClickListener {
            RecentStore.clear(this); refreshRecent(); toast("Đã xóa danh sách")
        }
        refreshRecent()
    }

    override fun onResume() {
        super.onResume()
        refreshRecent()
    }

    private fun tile(b: ViewTileBinding, icon: Int, box: Int, text: String, onClick: () -> Unit) {
        b.icon.setImageResource(icon)
        b.iconBox.setBackgroundResource(box)
        b.label.text = text
        b.root.setOnClickListener { onClick() }
    }

    private fun startCapture() {
        val options = GmsDocumentScannerOptions.Builder()
            .setGalleryImportAllowed(true)
            .setPageLimit(30)
            .setResultFormats(
                GmsDocumentScannerOptions.RESULT_FORMAT_JPEG,
                GmsDocumentScannerOptions.RESULT_FORMAT_PDF
            )
            .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
            .build()
        GmsDocumentScanning.getClient(options)
            .getStartScanIntent(this)
            .addOnSuccessListener { intentSender ->
                captureLauncher.launch(IntentSenderRequest.Builder(intentSender).build())
            }
            .addOnFailureListener { toast("Không mở được trình quét: ${it.message}") }
    }

    private fun toTemp(uri: Uri, ext: String, prefix: String = ""): File {
        val orig = Util.queryName(this, uri).substringBeforeLast('.', "file").ifBlank { "file" }
        val safe = orig.replace(Regex("[^A-Za-z0-9_\\-]"), "_").take(40)
        return Util.copyUriToCache(this, uri, "$prefix$safe.$ext")
    }

    private fun process(msg: String, work: () -> List<File>) {
        val dlg = AlertDialog.Builder(this).setMessage(msg).setCancelable(false).create()
        dlg.show()
        Thread {
            try {
                val files = work()
                runOnUiThread { dlg.dismiss(); onProduced(files) }
            } catch (e: Exception) {
                runOnUiThread { dlg.dismiss(); toast("Lỗi: ${e.message}") }
            }
        }.start()
    }

    private fun onProduced(files: List<File>) {
        files.forEach { RecentStore.add(this, it) }
        refreshRecent()
        when {
            files.isEmpty() -> toast("Không có kết quả")
            files.size == 1 -> {
                val f = files[0]
                AlertDialog.Builder(this)
                    .setTitle("Hoàn tất")
                    .setMessage("Đã tạo: ${f.name}")
                    .setPositiveButton("Mở") { _, _ -> Util.open(this, f) }
                    .setNeutralButton("Chia sẻ") { _, _ -> Util.share(this, f) }
                    .setNegativeButton("Đóng", null)
                    .show()
            }
            else -> toast("Đã tạo ${files.size} file — xem ở File gần đây")
        }
    }

    private fun refreshRecent() {
        val list = RecentStore.load(this)
        binding.emptyRecent.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        binding.recentRecycler.adapter = RecentAdapter(
            list,
            onOpen = { Util.open(this, File(it.path)) },
            onShare = { Util.share(this, File(it.path)) }
        )
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
}
