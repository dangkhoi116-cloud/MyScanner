package com.linh.myscanner

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import com.linh.myscanner.databinding.ActivityMainBinding
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: DocumentAdapter
    private val docs = mutableListOf<ScannedDoc>()

    private lateinit var scannerLauncher: ActivityResultLauncher<IntentSenderRequest>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = DocumentAdapter(
            docs,
            onClick = { openDoc(it) },
            onMore = { doc, _ -> showMore(doc) }
        )
        binding.recycler.layoutManager = LinearLayoutManager(this)
        binding.recycler.adapter = adapter

        binding.fabScan.setOnClickListener { startScan() }

        scannerLauncher = registerForActivityResult(
            ActivityResultContracts.StartIntentSenderForResult()
        ) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val scanResult =
                    GmsDocumentScanningResult.fromActivityResultIntent(result.data)
                scanResult?.let { handleScanResult(it) }
            }
        }

        reload()
    }

    private fun reload() {
        docs.clear()
        docs.addAll(DocumentStore.load(this))
        adapter.notifyDataSetChanged()
        binding.emptyView.visibility = if (docs.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
    }

    override fun onResume() {
        super.onResume()
        reload()
    }

    private fun startScan() {
        val options = GmsDocumentScannerOptions.Builder()
            .setGalleryImportAllowed(true)          // cho phep chon anh tu thu vien
            .setPageLimit(30)                        // toi da 30 trang
            .setResultFormats(
                GmsDocumentScannerOptions.RESULT_FORMAT_JPEG,
                GmsDocumentScannerOptions.RESULT_FORMAT_PDF
            )
            .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL) // tu cat vien + loc anh
            .build()

        GmsDocumentScanning.getClient(options)
            .getStartScanIntent(this)
            .addOnSuccessListener { intentSender ->
                scannerLauncher.launch(IntentSenderRequest.Builder(intentSender).build())
            }
            .addOnFailureListener {
                Toast.makeText(this, "Khong mo duoc trinh quet: ${it.message}", Toast.LENGTH_LONG).show()
            }
    }

    private fun handleScanResult(result: GmsDocumentScanningResult) {
        val id = System.currentTimeMillis().toString()
        val dir: File = DocumentStore.newDocDir(this, id)

        val doc = ScannedDoc(
            id = id,
            name = "Tài liệu " + SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date()),
            createdAt = System.currentTimeMillis()
        )

        // Luu tung trang anh JPEG (da duoc tu dong cat vien + loc)
        result.pages?.forEachIndexed { i, page ->
            val dest = File(dir, "page_$i.jpg")
            copyUriToFile(page.imageUri, dest)
            doc.pages.add(dest.absolutePath)
        }

        // Luu PDF do ML Kit tao san (neu co)
        result.pdf?.let { pdf ->
            val dest = File(dir, "$id.pdf")
            copyUriToFile(pdf.uri, dest)
            doc.pdfPath = dest.absolutePath
        }

        if (doc.pages.isEmpty()) {
            Toast.makeText(this, "Khong co trang nao duoc quet.", Toast.LENGTH_SHORT).show()
            return
        }

        DocumentStore.add(this, doc)
        reload()
        openDoc(doc)
    }

    private fun copyUriToFile(uri: Uri, dest: File) {
        contentResolver.openInputStream(uri)?.use { input ->
            dest.outputStream().use { output -> input.copyTo(output) }
        }
    }

    private fun openDoc(doc: ScannedDoc) {
        startActivity(Intent(this, DocumentDetailActivity::class.java).putExtra("docId", doc.id))
    }

    private fun showMore(doc: ScannedDoc) {
        val items = arrayOf(getString(R.string.rename), getString(R.string.delete))
        AlertDialog.Builder(this)
            .setTitle(doc.name)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> renameDoc(doc)
                    1 -> deleteDoc(doc)
                }
            }
            .show()
    }

    private fun renameDoc(doc: ScannedDoc) {
        val input = android.widget.EditText(this).apply { setText(doc.name) }
        AlertDialog.Builder(this)
            .setTitle(R.string.rename)
            .setView(input)
            .setPositiveButton("OK") { _, _ ->
                doc.name = input.text.toString().ifBlank { doc.name }
                DocumentStore.update(this, doc)
                reload()
            }
            .setNegativeButton("Hủy", null)
            .show()
    }

    private fun deleteDoc(doc: ScannedDoc) {
        AlertDialog.Builder(this)
            .setMessage("Xóa \"${doc.name}\"?")
            .setPositiveButton(R.string.delete) { _, _ ->
                DocumentStore.delete(this, doc)
                reload()
            }
            .setNegativeButton("Hủy", null)
            .show()
    }
}
