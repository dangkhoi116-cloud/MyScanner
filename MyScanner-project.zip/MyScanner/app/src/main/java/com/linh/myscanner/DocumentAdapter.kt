package com.linh.myscanner

import android.graphics.BitmapFactory
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class DocumentAdapter(
    private val items: List<ScannedDoc>,
    private val onClick: (ScannedDoc) -> Unit,
    private val onMore: (ScannedDoc, View) -> Unit
) : RecyclerView.Adapter<DocumentAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val thumb: ImageView = v.findViewById(R.id.thumb)
        val title: TextView = v.findViewById(R.id.title)
        val subtitle: TextView = v.findViewById(R.id.subtitle)
        val btnMore: ImageButton = v.findViewById(R.id.btnMore)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_document, parent, false)
        return VH(v)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val doc = items[position]
        holder.title.text = doc.name
        val date = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(doc.createdAt))
        holder.subtitle.text = "${doc.pages.size} ${holder.itemView.context.getString(R.string.pages)} · $date"

        val first = doc.pages.firstOrNull()
        if (first != null && File(first).exists()) {
            val bmp = BitmapFactory.decodeFile(first, BitmapFactory.Options().apply { inSampleSize = 4 })
            if (bmp != null) holder.thumb.setImageBitmap(bmp)
            else holder.thumb.setImageResource(R.drawable.ic_doc)
        } else {
            holder.thumb.setImageResource(R.drawable.ic_doc)
        }

        holder.itemView.setOnClickListener { onClick(doc) }
        holder.btnMore.setOnClickListener { onMore(doc, it) }
    }
}
