package com.linh.myscanner

import android.content.Context
import org.json.JSONArray
import java.io.File

/** Luu & quan ly danh sach tai lieu bang 1 file index.json trong bo nho rieng cua app. */
object DocumentStore {

    private fun rootDir(ctx: Context): File =
        File(ctx.filesDir, "docs").apply { if (!exists()) mkdirs() }

    private fun indexFile(ctx: Context): File = File(rootDir(ctx), "index.json")

    fun load(ctx: Context): MutableList<ScannedDoc> {
        val f = indexFile(ctx)
        if (!f.exists()) return mutableListOf()
        return try {
            val arr = JSONArray(f.readText())
            val list = mutableListOf<ScannedDoc>()
            for (i in 0 until arr.length()) list.add(ScannedDoc.fromJson(arr.getJSONObject(i)))
            list.sortByDescending { it.createdAt }
            list
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    fun saveAll(ctx: Context, docs: List<ScannedDoc>) {
        val arr = JSONArray()
        docs.forEach { arr.put(it.toJson()) }
        indexFile(ctx).writeText(arr.toString())
    }

    /** Tao thu muc moi cho 1 tai lieu va tra ve no. */
    fun newDocDir(ctx: Context, id: String): File =
        File(rootDir(ctx), id).apply { if (!exists()) mkdirs() }

    fun add(ctx: Context, doc: ScannedDoc) {
        val list = load(ctx)
        list.add(doc)
        saveAll(ctx, list)
    }

    fun update(ctx: Context, doc: ScannedDoc) {
        val list = load(ctx)
        val i = list.indexOfFirst { it.id == doc.id }
        if (i >= 0) list[i] = doc else list.add(doc)
        saveAll(ctx, list)
    }

    fun delete(ctx: Context, doc: ScannedDoc) {
        File(rootDir(ctx), doc.id).deleteRecursively()
        val list = load(ctx).filter { it.id != doc.id }
        saveAll(ctx, list)
    }
}
