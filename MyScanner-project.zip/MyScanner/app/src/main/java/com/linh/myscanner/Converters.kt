package com.linh.myscanner

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.multipdf.PDFMergerUtility
import com.tom_roush.pdfbox.multipdf.Splitter
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object Converters {

    // ---- Anh -> PDF ----
    fun imagesToPdf(ctx: Context, uris: List<Uri>): File {
        val paths = uris.mapIndexed { i, u -> Util.copyUriToCache(ctx, u, "img_$i.jpg").absolutePath }
        val out = File(Util.outDir(ctx), "PDF_${Util.stamp()}.pdf")
        return PdfHelper.buildPdf(paths, out)
    }

    // ---- PDF -> Anh (PNG) ----
    fun pdfToImages(ctx: Context, pdf: File): List<File> {
        val result = mutableListOf<File>()
        val pfd = ParcelFileDescriptor.open(pdf, ParcelFileDescriptor.MODE_READ_ONLY)
        val renderer = PdfRenderer(pfd)
        val base = pdf.nameWithoutExtension
        for (i in 0 until renderer.pageCount) {
            val page = renderer.openPage(i)
            var w = page.width * 2
            var h = page.height * 2
            val cap = 2200
            if (maxOf(w, h) > cap) {
                val s = cap.toFloat() / maxOf(w, h)
                w = (w * s).toInt(); h = (h * s).toInt()
            }
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE)
            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            page.close()
            val f = File(Util.outDir(ctx), "${base}_trang${i + 1}.png")
            FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.PNG, 95, it) }
            bmp.recycle()
            result.add(f)
        }
        renderer.close(); pfd.close()
        return result
    }

    // ---- Ghep PDF ----
    fun mergePdfs(ctx: Context, files: List<File>): File {
        val out = File(Util.outDir(ctx), "Ghep_${Util.stamp()}.pdf")
        val mu = PDFMergerUtility()
        files.forEach { mu.addSource(it) }
        mu.destinationFileName = out.absolutePath
        mu.mergeDocuments(MemoryUsageSetting.setupMainMemoryOnly())
        return out
    }

    // ---- Tach PDF (moi trang 1 file) ----
    fun splitPdf(ctx: Context, pdf: File): List<File> {
        val result = mutableListOf<File>()
        val src = PDDocument.load(pdf)
        val parts = Splitter().split(src)
        val base = pdf.nameWithoutExtension
        parts.forEachIndexed { i, d ->
            val f = File(Util.outDir(ctx), "${base}_phan${i + 1}.pdf")
            d.save(f); d.close()
            result.add(f)
        }
        src.close()
        return result
    }

    // ---- PDF -> Word (.docx) : trich xuat van ban ----
    fun pdfToWord(ctx: Context, pdf: File): File {
        val doc = PDDocument.load(pdf)
        val text = try { PDFTextStripper().getText(doc) } finally { doc.close() }
        val lines = text.split("\n")
        val out = File(Util.outDir(ctx), "${pdf.nameWithoutExtension}.docx")
        writeDocx(lines, out)
        return out
    }

    // ---- Word (.docx) -> PDF : doc van ban, ve ra PDF ----
    fun wordToPdf(ctx: Context, docx: File): File {
        val xml = readZipEntry(docx, "word/document.xml") ?: ""
        val paragraphs = parseDocxParagraphs(xml)
        val out = File(Util.outDir(ctx), "${docx.nameWithoutExtension}.pdf")
        renderTextToPdf(paragraphs, out)
        return out
    }

    // ===== Helpers =====

    private fun readZipEntry(zip: File, entryName: String): String? {
        ZipInputStream(zip.inputStream()).use { zis ->
            var e: ZipEntry? = zis.nextEntry
            while (e != null) {
                if (e.name == entryName) return zis.readBytes().toString(Charsets.UTF_8)
                e = zis.nextEntry
            }
        }
        return null
    }

    private fun parseDocxParagraphs(xml: String): List<String> {
        if (xml.isBlank()) return listOf("")
        val paras = mutableListOf<String>()
        val pRegex = Regex("<w:p[ >].*?</w:p>", RegexOption.DOT_MATCHES_ALL)
        val tRegex = Regex("<w:t[^>]*>(.*?)</w:t>", RegexOption.DOT_MATCHES_ALL)
        val matches = pRegex.findAll(xml).toList()
        if (matches.isEmpty()) {
            // fallback: lay het text
            val sb = StringBuilder()
            tRegex.findAll(xml).forEach { sb.append(unescape(it.groupValues[1])) }
            return sb.toString().split("\n")
        }
        for (m in matches) {
            val seg = m.value.replace(Regex("<w:br\\s*/?>"), "\n").replace(Regex("<w:tab\\s*/?>"), "    ")
            val sb = StringBuilder()
            tRegex.findAll(seg).forEach { sb.append(unescape(it.groupValues[1])) }
            paras.add(sb.toString())
        }
        return paras
    }

    private fun unescape(s: String): String = s
        .replace("&lt;", "<").replace("&gt;", ">")
        .replace("&quot;", "\"").replace("&apos;", "'")
        .replace("&amp;", "&")

    private fun escape(s: String): String = s
        .replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        .replace("\"", "&quot;")

    private fun renderTextToPdf(paragraphs: List<String>, out: File) {
        val pageW = 595; val pageH = 842; val margin = 45
        val maxW = (pageW - 2 * margin).toFloat()
        val paint = Paint().apply {
            color = Color.BLACK; textSize = 12f; isAntiAlias = true
        }
        val lineH = 17f
        val doc = PdfDocument()
        var pageNum = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNum).create())
        var canvas = page.canvas
        var y = margin + lineH

        fun newPage() {
            doc.finishPage(page)
            pageNum++
            page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNum).create())
            canvas = page.canvas
            y = margin + lineH
        }

        for (para in paragraphs) {
            val text = para.ifEmpty { "" }
            val wrapped = if (text.isEmpty()) listOf("") else wrapLines(text, paint, maxW)
            for (ln in wrapped) {
                if (y > pageH - margin) newPage()
                canvas.drawText(ln, margin.toFloat(), y, paint)
                y += lineH
            }
        }
        doc.finishPage(page)
        out.outputStream().use { doc.writeTo(it) }
        doc.close()
    }

    private fun wrapLines(text: String, paint: Paint, maxW: Float): List<String> {
        val lines = mutableListOf<String>()
        for (rawLine in text.split("\n")) {
            if (rawLine.isEmpty()) { lines.add(""); continue }
            val words = rawLine.split(" ")
            var cur = StringBuilder()
            for (w in words) {
                val test = if (cur.isEmpty()) w else "$cur $w"
                if (paint.measureText(test) <= maxW) {
                    cur = StringBuilder(test)
                } else {
                    if (cur.isNotEmpty()) { lines.add(cur.toString()); cur = StringBuilder() }
                    if (paint.measureText(w) > maxW) {
                        var c = StringBuilder()
                        for (ch in w) {
                            if (paint.measureText(c.toString() + ch) <= maxW) c.append(ch)
                            else { lines.add(c.toString()); c = StringBuilder().append(ch) }
                        }
                        cur = c
                    } else cur = StringBuilder(w)
                }
            }
            lines.add(cur.toString())
        }
        return lines
    }

    private fun writeDocx(lines: List<String>, out: File) {
        val contentTypes = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>"""
        val rels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>"""
        val body = StringBuilder()
        body.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        body.append("""<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>""")
        for (ln in lines) {
            body.append("<w:p><w:r><w:t xml:space=\"preserve\">").append(escape(ln)).append("</w:t></w:r></w:p>")
        }
        body.append("</w:body></w:document>")

        ZipOutputStream(FileOutputStream(out)).use { zos ->
            fun put(name: String, data: String) {
                zos.putNextEntry(ZipEntry(name))
                zos.write(data.toByteArray(Charsets.UTF_8))
                zos.closeEntry()
            }
            put("[Content_Types].xml", contentTypes)
            put("_rels/.rels", rels)
            put("word/document.xml", body.toString())
        }
    }
}
