package com.linh.myscanner

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RecentAdapter(
    private val items: List<RecentFile>,
    private val onOpen: (RecentFile) -> Unit,
    private val onShare: (RecentFile) -> Unit
) : RecyclerView.Adapter<RecentAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val name: TextView = v.findViewById(R.id.rName)
        val info: TextView = v.findViewById(R.id.rInfo)
        val share: ImageButton = v.findViewById(R.id.rShare)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_recent, parent, false)
        return VH(v)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val f = items[position]
        holder.name.text = f.name
        val date = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(f.time))
        holder.info.text = date
        holder.itemView.setOnClickListener { onOpen(f) }
        holder.share.setOnClickListener { onShare(f) }
    }
}
