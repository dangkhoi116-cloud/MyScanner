package com.linh.myscanner

import android.graphics.BitmapFactory
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import java.io.File

class PageAdapter(private val pages: List<String>) :
    RecyclerView.Adapter<PageAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val image: ImageView = v.findViewById(R.id.pageImage)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_page, parent, false)
        return VH(v)
    }

    override fun getItemCount() = pages.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val path = pages[position]
        if (File(path).exists()) {
            val bmp = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = 2 })
            holder.image.setImageBitmap(bmp)
        } else {
            holder.image.setImageResource(R.drawable.ic_doc)
        }
    }
}
