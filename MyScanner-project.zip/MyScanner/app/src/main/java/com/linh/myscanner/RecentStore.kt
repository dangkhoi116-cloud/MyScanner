package com.linh.myscanner

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class RecentFile(val name: String, val path: String, val time: Long)

object RecentStore {
    private const val PREF = "recent_files"
    private const val KEY = "list"

    fun load(ctx: Context): MutableList<RecentFile> {
        val raw = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        val list = mutableListOf<RecentFile>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val f = RecentFile(o.getString("name"), o.getString("path"), o.getLong("time"))
                if (File(f.path).exists()) list.add(f)
            }
        } catch (_: Exception) {}
        list.sortByDescending { it.time }
        return list
    }

    private fun save(ctx: Context, list: List<RecentFile>) {
        val arr = JSONArray()
        list.forEach { f ->
            arr.put(JSONObject().put("name", f.name).put("path", f.path).put("time", f.time))
        }
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }

    fun add(ctx: Context, file: File) {
        val list = load(ctx).filter { it.path != file.absolutePath }.toMutableList()
        list.add(0, RecentFile(file.name, file.absolutePath, System.currentTimeMillis()))
        save(ctx, list.take(50))
    }

    fun clear(ctx: Context) = save(ctx, emptyList())
}
