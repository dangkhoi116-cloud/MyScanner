package com.linh.myscanner

import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Rect
import android.graphics.pdf.PdfDocument
import java.io.File

/** Gop nhieu anh thanh 1 file PDF nhieu trang (kho A4). */
object PdfHelper {

    private const val A4_W = 595   // diem (72 dpi)
    private const val A4_H = 842

    fun buildPdf(imagePaths: List<String>, outFile: File): File {
        val doc = PdfDocument()
        imagePaths.forEachIndexed { index, path ->
            val bmp = BitmapFactory.decodeFile(path) ?: return@forEachIndexed
            val pageInfo = PdfDocument.PageInfo.Builder(A4_W, A4_H, index + 1).create()
            val page = doc.startPage(pageInfo)
            val canvas: Canvas = page.canvas

            // Scale anh vua khung A4, giu ti le
            val scale = minOf(
                A4_W.toFloat() / bmp.width,
                A4_H.toFloat() / bmp.height
            )
            val w = (bmp.width * scale).toInt()
            val h = (bmp.height * scale).toInt()
            val left = (A4_W - w) / 2
            val top = (A4_H - h) / 2
            canvas.drawBitmap(bmp, null, Rect(left, top, left + w, top + h), null)
            doc.finishPage(page)
            bmp.recycle()
        }
        outFile.outputStream().use { doc.writeTo(it) }
        doc.close()
        return outFile
    }
}
