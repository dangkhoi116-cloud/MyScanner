# MyScanner — App quét tài liệu cho Android

App quét tài liệu giống **Any Scanner / CamScanner**, viết bằng Kotlin, dùng **Google ML Kit Document Scanner** (chụp + tự động cắt viền + lọc ảnh có sẵn của Google) và **ML Kit Text Recognition** (OCR).

## Tính năng

- **Chụp & tự động cắt viền tài liệu** — giao diện quét của Google tự nhận biết mép giấy, cho kéo chỉnh 4 góc.
- **Lọc ảnh làm rõ như máy scan** — chế độ làm sạch, đen trắng, tăng tương phản (có sẵn trong trình quét ML Kit).
- **Xuất PDF nhiều trang** — gộp các trang đã quét thành 1 file PDF (A4).
- **Lưu & quản lý tài liệu** — danh sách các bản scan, đổi tên, xóa, mở lại.
- **OCR — trích xuất văn bản như file Word** — nhận dạng chữ trong ảnh (hỗ trợ tiếng Việt có dấu), sao chép hoặc chia sẻ ra văn bản `.txt`.
- **Chia sẻ** PDF / văn bản sang Zalo, Gmail, Drive…

## Cách build ra file APK

Cần **Android Studio** (bản Hedgehog trở lên).

1. Giải nén thư mục `MyScanner`.
2. Mở Android Studio → **File ▸ Open** → chọn thư mục `MyScanner`.
3. Đợi Android Studio tải Gradle và các thư viện (cần mạng, lần đầu vài phút).
4. Cắm điện thoại Android (bật USB debugging) hoặc dùng máy ảo → nhấn **Run ▶**.
5. Để tạo file cài đặt: **Build ▸ Build Bundle(s)/APK(s) ▸ Build APK(s)**. File APK nằm ở `app/build/outputs/apk/debug/app-debug.apk`.

> Lưu ý: Máy chạy app cần có **Google Play Services** (hầu hết điện thoại Android đều có). Trình quét ML Kit sẽ tự tải module quét lần đầu sử dụng.

## Yêu cầu kỹ thuật

- minSdk 21 (Android 5.0) trở lên
- compileSdk / targetSdk 34
- Kotlin 1.9, Android Gradle Plugin 8.5

## Cấu trúc mã nguồn

```
app/src/main/java/com/linh/myscanner/
  MainActivity.kt           # Danh sách tài liệu + nút quét (gọi ML Kit Document Scanner)
  DocumentDetailActivity.kt # Xem các trang, xuất/chia sẻ PDF, chạy OCR
  DocumentAdapter.kt        # Danh sách tài liệu (RecyclerView)
  PageAdapter.kt            # Danh sách trang ảnh
  DocumentStore.kt          # Lưu & đọc danh sách (index.json trong bộ nhớ app)
  PdfHelper.kt              # Gộp ảnh thành PDF nhiều trang
  ScannedDoc.kt             # Mô hình dữ liệu 1 tài liệu
```

## Gợi ý mở rộng

- Đặt tên file PDF theo nội dung OCR.
- Thêm sắp xếp / tìm kiếm tài liệu.
- Thêm watermark hoặc khóa PDF bằng mật khẩu.
- Đồng bộ lên Google Drive.
